﻿namespace EmployeeWebApp.Models
{
    public enum Gender
    {
        Male,Female
    }
}
