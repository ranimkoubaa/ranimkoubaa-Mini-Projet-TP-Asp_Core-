﻿using tp3.Models;
using tp3.Models;
using System.Collections.Generic;
using System.Linq;
using Microsoft.EntityFrameworkCore;

namespace tp3.Repositories
{
    public class StudentRepository : IStudentRepository
    {
        private readonly StudentContext _context;

        public StudentRepository(StudentContext context)
        {
            _context = context;
        }

        public IList<Student> GetAll()
        {
            return _context.Students.OrderBy(x => x.StudentName).Include(x => x.School).ToList();
        }

        public Student GetById(int id)
        {
            return _context.Students.Where(x => x.StudentId == id).Include(x => x.School).SingleOrDefault();
        }

        public void Add(Student s)
        {
            _context.Students.Add(s);
            _context.SaveChanges();
        }

        public void Edit(Student s)
        {
            Student existingStudent = _context.Students.Find(s.StudentId);
            if (existingStudent != null)
            {
                existingStudent.StudentName = s.StudentName;
                existingStudent.Age = s.Age;
                existingStudent.BirthDate = s.BirthDate;
                existingStudent.SchoolID = s.SchoolID;
                _context.SaveChanges();
            }
        }

        public void Delete(Student s)
        {
            Student existingStudent = _context.Students.Find(s.StudentId);
            if (existingStudent != null)
            {
                _context.Students.Remove(existingStudent);
                _context.SaveChanges();
            }
        }

        public IList<Student> GetStudentsBySchoolID(int? schoolId)
        {
            return _context.Students.Where(s => s.SchoolID == schoolId)
                                    .OrderBy(s => s.StudentName)
                                    .Include(std => std.School)
                                    .ToList();
        }

        public IList<Student> FindByName(string name)
        {
            return _context.Students.Where(s => s.StudentName.Contains(name))
                                    .Include(std => std.School)
                                    .ToList();
        }
    }
}
