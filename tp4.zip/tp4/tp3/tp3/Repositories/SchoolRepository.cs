﻿using tp3.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using tp3.Models;

namespace tp3.Repositories
{
    public class SchoolRepository : ISchoolRepository
    {
        private readonly StudentContext _context;

        public SchoolRepository(StudentContext context)
        {
            _context = context;
        }

        public IList<School> GetAll()
        {
            return _context.Schools.OrderBy(s => s.SchoolName).ToList();
        }

        public School GetById(int id)
        {
            return _context.Schools.Find(id);
        }

        public void Add(School school)
        {
            _context.Schools.Add(school);
            _context.SaveChanges();
        }

        public void Edit(School school)
        {
            var existingSchool = _context.Schools.Find(school.SchoolID);
            if (existingSchool != null)
            {
                existingSchool.SchoolName = school.SchoolName;
                existingSchool.SchoolAdress = school.SchoolAdress;
                _context.SaveChanges();
            }
        }

        public void Delete(School school)
        {
            var existingSchool = _context.Schools.Find(school.SchoolID);
            if (existingSchool != null)
            {
                _context.Schools.Remove(existingSchool);
                _context.SaveChanges();
            }
        }

        public double StudentAgeAverage(int schoolId)
        {
            var studentCount = StudentCount(schoolId);
            if (studentCount == 0)
                return 0;
            
            return _context.Students.Where(s => s.SchoolID == schoolId).Average(e => e.Age);
        }

        public int StudentCount(int schoolId)
        {
            return _context.Students.Count(s => s.SchoolID == schoolId);
        }

        public void Delete(int id)
        {
            var school = _context.Schools.Find(id);
            if (school != null)
            {
                _context.Schools.Remove(school);
                _context.SaveChanges();
            }
           
        }
    }
}
