﻿namespace Atelier1.Controllers
{
    public class controller
    {
    }
}