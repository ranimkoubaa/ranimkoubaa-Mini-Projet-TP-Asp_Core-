﻿using Atelier3.Models;
using Atelier3.Repositories;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace Atelier3.Controllers
{
    public class SchoolController : Controller
    {
        private readonly ISchoolRepository _schoolRepository;

        public SchoolController(ISchoolRepository schoolRepository)
        {
            _schoolRepository = schoolRepository;
        }

        // GET: School
        public IActionResult Index()
        {
            var schools = _schoolRepository.GetAll();
            return View(schools);
        }

        // GET: School/Details/5
        public IActionResult Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var school = _schoolRepository.GetById(id.Value);
            if (school == null)
            {
                return NotFound();
            }

            return View(school);
        }

        // GET: School/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: SchoolController/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(School school)
        {
            try
            {
                _schoolRepository.Add(school);
                return RedirectToAction(nameof(Index));

            }
            catch (Exception ex)
            {
                ModelState.AddModelError(string.Empty, $"An error occurred: {ex.Message}");
            }
            return View(school);
        }
        // GET: SchoolController/Edit/5
        public ActionResult Edit(int id)
        {
            var school = _schoolRepository.GetById(id);
            if (school == null)
            {
                return NotFound();
            }
            return View(school);
        }

        // POST: SchoolController/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(int id, School school)
        {
            try
            {
                if (id != school.SchoolID)
                {
                    return NotFound();
                }


                _schoolRepository.Edit(school);
                return RedirectToAction(nameof(Index));

            }
            catch (Exception ex)
            {
                ModelState.AddModelError(string.Empty, $"An error occurred: {ex.Message}");
            }
            return View(school);
        }


        // GET: School/Delete/5
        public IActionResult Delete(int id)
        {

            var school = _schoolRepository.GetById(id);
            if (school == null)
            {
                return NotFound();
            }

            return View(school);
        }

        // POST: School/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public IActionResult DeleteConfirmed(int id)
        {
            var school = _schoolRepository.GetById(id);
            if (school == null)
            {
                return NotFound();
            }

            _schoolRepository.Delete(school);
            return RedirectToAction(nameof(Index));
        }
    }
}
